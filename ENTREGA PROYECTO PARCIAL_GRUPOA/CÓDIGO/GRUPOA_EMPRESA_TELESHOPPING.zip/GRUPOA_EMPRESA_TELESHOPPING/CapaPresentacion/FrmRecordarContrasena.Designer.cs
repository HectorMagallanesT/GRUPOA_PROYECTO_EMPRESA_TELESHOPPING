﻿namespace CapaPresentacion
{
    partial class FrmRecordarContrasena
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxRecordar = new System.Windows.Forms.GroupBox();
            this.txtIngresarCI = new System.Windows.Forms.TextBox();
            this.lblCIRecordar = new System.Windows.Forms.Label();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.groupBoxRecordar.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxRecordar
            // 
            this.groupBoxRecordar.Controls.Add(this.txtIngresarCI);
            this.groupBoxRecordar.Controls.Add(this.lblCIRecordar);
            this.groupBoxRecordar.Controls.Add(this.btnMostrar);
            this.groupBoxRecordar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxRecordar.Location = new System.Drawing.Point(42, 46);
            this.groupBoxRecordar.Name = "groupBoxRecordar";
            this.groupBoxRecordar.Size = new System.Drawing.Size(305, 260);
            this.groupBoxRecordar.TabIndex = 1;
            this.groupBoxRecordar.TabStop = false;
            this.groupBoxRecordar.Text = "Recordar Contraseña:";
            // 
            // txtIngresarCI
            // 
            this.txtIngresarCI.Location = new System.Drawing.Point(65, 108);
            this.txtIngresarCI.Multiline = true;
            this.txtIngresarCI.Name = "txtIngresarCI";
            this.txtIngresarCI.Size = new System.Drawing.Size(204, 30);
            this.txtIngresarCI.TabIndex = 2;
            // 
            // lblCIRecordar
            // 
            this.lblCIRecordar.AutoSize = true;
            this.lblCIRecordar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCIRecordar.Location = new System.Drawing.Point(21, 108);
            this.lblCIRecordar.Name = "lblCIRecordar";
            this.lblCIRecordar.Size = new System.Drawing.Size(38, 25);
            this.lblCIRecordar.TabIndex = 1;
            this.lblCIRecordar.Text = "CI:";
            // 
            // btnMostrar
            // 
            this.btnMostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrar.Location = new System.Drawing.Point(99, 204);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(112, 36);
            this.btnMostrar.TabIndex = 0;
            this.btnMostrar.Text = "Mostrar";
            this.btnMostrar.UseVisualStyleBackColor = true;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // FrmRecordarContrasena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(388, 352);
            this.Controls.Add(this.groupBoxRecordar);
            this.Name = "FrmRecordarContrasena";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recuperar Contraseña";
            this.groupBoxRecordar.ResumeLayout(false);
            this.groupBoxRecordar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxRecordar;
        private System.Windows.Forms.TextBox txtIngresarCI;
        private System.Windows.Forms.Label lblCIRecordar;
        private System.Windows.Forms.Button btnMostrar;
    }
}