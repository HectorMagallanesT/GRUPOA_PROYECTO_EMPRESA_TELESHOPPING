﻿namespace CapaPresentacion
{
    partial class FrmLoginUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLoginUsuario));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnInfoContrasena = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPageCrearNuevaCuenta = new System.Windows.Forms.TabPage();
            this.pnlCrearCuenta = new System.Windows.Forms.Panel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.txtNombreCuenta = new System.Windows.Forms.TextBox();
            this.txtConfirmarContrasena = new System.Windows.Forms.TextBox();
            this.txtContrasena = new System.Windows.Forms.TextBox();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.btnCrearUsuario = new System.Windows.Forms.Button();
            this.lblConfirmarContraseña = new System.Windows.Forms.Label();
            this.lblContraseña = new System.Windows.Forms.Label();
            this.lblNombreApellido = new System.Windows.Forms.Label();
            this.lblCI = new System.Windows.Forms.Label();
            this.lblInfoCuenta = new System.Windows.Forms.Label();
            this.pnlEncabezadoCrearCuenta = new System.Windows.Forms.Panel();
            this.lblEncabezadoRegistro = new System.Windows.Forms.Label();
            this.tabPageInicioSesion = new System.Windows.Forms.TabPage();
            this.pnlCuerpoTitulo = new System.Windows.Forms.Panel();
            this.linkLblContraseñaOlvidada = new System.Windows.Forms.LinkLabel();
            this.pictureBoxLogoSesion = new System.Windows.Forms.PictureBox();
            this.txtContrasenaLogin = new System.Windows.Forms.TextBox();
            this.txtCILogin = new System.Windows.Forms.TextBox();
            this.lblContrasenaLogin = new System.Windows.Forms.Label();
            this.lblCILogin = new System.Windows.Forms.Label();
            this.btnAcceder = new System.Windows.Forms.Button();
            this.pnInicioTitulo = new System.Windows.Forms.Panel();
            this.lblinicio = new System.Windows.Forms.Label();
            this.pictureBoxLogin = new System.Windows.Forms.PictureBox();
            this.tabControlUsuario = new System.Windows.Forms.TabControl();
            this.Actualizar = new System.Windows.Forms.TabPage();
            this.pnlActualizar = new System.Windows.Forms.Panel();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.txtActualizarEmail = new System.Windows.Forms.TextBox();
            this.lblActualizarEmail = new System.Windows.Forms.Label();
            this.txtActualizarNYA = new System.Windows.Forms.TextBox();
            this.txtActualizarConfirmarContrasena = new System.Windows.Forms.TextBox();
            this.txtActualizarContrasena = new System.Windows.Forms.TextBox();
            this.txtBuscarCI = new System.Windows.Forms.TextBox();
            this.lblActualizarConfirmarContrasena = new System.Windows.Forms.Label();
            this.lblActualizarContrasena = new System.Windows.Forms.Label();
            this.lblActualizarNombreYApellido = new System.Windows.Forms.Label();
            this.lblActualizarCI = new System.Windows.Forms.Label();
            this.lblActualizarInfo = new System.Windows.Forms.Label();
            this.pnlActualziar1 = new System.Windows.Forms.Panel();
            this.lblActualizar = new System.Windows.Forms.Label();
            this.tabPageADMIN = new System.Windows.Forms.TabPage();
            this.lblAdmin = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtADMINContrasena = new System.Windows.Forms.TextBox();
            this.txtADMINCI = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAccederADMIN = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.linkLabelEliminarCuenta = new System.Windows.Forms.LinkLabel();
            this.tabPageCrearNuevaCuenta.SuspendLayout();
            this.pnlCrearCuenta.SuspendLayout();
            this.pnlEncabezadoCrearCuenta.SuspendLayout();
            this.tabPageInicioSesion.SuspendLayout();
            this.pnlCuerpoTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogoSesion)).BeginInit();
            this.pnInicioTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogin)).BeginInit();
            this.tabControlUsuario.SuspendLayout();
            this.Actualizar.SuspendLayout();
            this.pnlActualizar.SuspendLayout();
            this.pnlActualziar1.SuspendLayout();
            this.tabPageADMIN.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // btnInfoContrasena
            // 
            this.btnInfoContrasena.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnInfoContrasena.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInfoContrasena.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnInfoContrasena.Location = new System.Drawing.Point(607, 349);
            this.btnInfoContrasena.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnInfoContrasena.Name = "btnInfoContrasena";
            this.btnInfoContrasena.Size = new System.Drawing.Size(30, 22);
            this.btnInfoContrasena.TabIndex = 12;
            this.btnInfoContrasena.Text = "?";
            this.toolTip1.SetToolTip(this.btnInfoContrasena, "La CONTRASEÑA debe tener como mínimo:\r\n8 caracteres de longitud.\r\n1 caracter en m" +
        "ayúscula.\r\n2 caracteres en minúsculas.\r\n2 números.");
            this.btnInfoContrasena.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(590, 386);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 22);
            this.button2.TabIndex = 12;
            this.button2.Text = "?";
            this.toolTip1.SetToolTip(this.button2, "La CONTRASEÑA debe tener como mínimo:\r\n8 caracteres de longitud.\r\n1 caracter en m" +
        "ayúscula.\r\n2 caracteres en minúsculas.\r\n2 números.");
            this.toolTip2.SetToolTip(this.button2, "La CONTRASEÑA debe tener como mínimo:\r\n8 caracteres de longitud.\r\n1 caracter en m" +
        "ayúscula.\r\n2 caracteres en minúsculas.\r\n2 números.\r\n");
            this.button2.UseVisualStyleBackColor = false;
            // 
            // tabPageCrearNuevaCuenta
            // 
            this.tabPageCrearNuevaCuenta.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPageCrearNuevaCuenta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPageCrearNuevaCuenta.BackgroundImage")));
            this.tabPageCrearNuevaCuenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPageCrearNuevaCuenta.Controls.Add(this.pnlCrearCuenta);
            this.tabPageCrearNuevaCuenta.Location = new System.Drawing.Point(4, 25);
            this.tabPageCrearNuevaCuenta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageCrearNuevaCuenta.Name = "tabPageCrearNuevaCuenta";
            this.tabPageCrearNuevaCuenta.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageCrearNuevaCuenta.Size = new System.Drawing.Size(1379, 661);
            this.tabPageCrearNuevaCuenta.TabIndex = 1;
            this.tabPageCrearNuevaCuenta.Text = "Registrarse";
            // 
            // pnlCrearCuenta
            // 
            this.pnlCrearCuenta.BackColor = System.Drawing.Color.White;
            this.pnlCrearCuenta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCrearCuenta.Controls.Add(this.txtEmail);
            this.pnlCrearCuenta.Controls.Add(this.lblCorreo);
            this.pnlCrearCuenta.Controls.Add(this.btnInfoContrasena);
            this.pnlCrearCuenta.Controls.Add(this.txtNombreCuenta);
            this.pnlCrearCuenta.Controls.Add(this.txtConfirmarContrasena);
            this.pnlCrearCuenta.Controls.Add(this.txtContrasena);
            this.pnlCrearCuenta.Controls.Add(this.txtCI);
            this.pnlCrearCuenta.Controls.Add(this.btnCrearUsuario);
            this.pnlCrearCuenta.Controls.Add(this.lblConfirmarContraseña);
            this.pnlCrearCuenta.Controls.Add(this.lblContraseña);
            this.pnlCrearCuenta.Controls.Add(this.lblNombreApellido);
            this.pnlCrearCuenta.Controls.Add(this.lblCI);
            this.pnlCrearCuenta.Controls.Add(this.lblInfoCuenta);
            this.pnlCrearCuenta.Controls.Add(this.pnlEncabezadoCrearCuenta);
            this.pnlCrearCuenta.Location = new System.Drawing.Point(254, 41);
            this.pnlCrearCuenta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlCrearCuenta.Name = "pnlCrearCuenta";
            this.pnlCrearCuenta.Size = new System.Drawing.Size(847, 564);
            this.pnlCrearCuenta.TabIndex = 1;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.SystemColors.Info;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Location = new System.Drawing.Point(245, 282);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(356, 22);
            this.txtEmail.TabIndex = 14;
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblCorreo.Location = new System.Drawing.Point(245, 255);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(65, 25);
            this.lblCorreo.TabIndex = 13;
            this.lblCorreo.Text = "E-mail:";
            // 
            // txtNombreCuenta
            // 
            this.txtNombreCuenta.BackColor = System.Drawing.SystemColors.Info;
            this.txtNombreCuenta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNombreCuenta.Location = new System.Drawing.Point(245, 158);
            this.txtNombreCuenta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreCuenta.Name = "txtNombreCuenta";
            this.txtNombreCuenta.Size = new System.Drawing.Size(356, 22);
            this.txtNombreCuenta.TabIndex = 11;
            // 
            // txtConfirmarContrasena
            // 
            this.txtConfirmarContrasena.BackColor = System.Drawing.SystemColors.Info;
            this.txtConfirmarContrasena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtConfirmarContrasena.Location = new System.Drawing.Point(245, 422);
            this.txtConfirmarContrasena.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtConfirmarContrasena.Name = "txtConfirmarContrasena";
            this.txtConfirmarContrasena.PasswordChar = '*';
            this.txtConfirmarContrasena.Size = new System.Drawing.Size(356, 22);
            this.txtConfirmarContrasena.TabIndex = 10;
            // 
            // txtContrasena
            // 
            this.txtContrasena.BackColor = System.Drawing.SystemColors.Info;
            this.txtContrasena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContrasena.Location = new System.Drawing.Point(245, 349);
            this.txtContrasena.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtContrasena.Name = "txtContrasena";
            this.txtContrasena.PasswordChar = '*';
            this.txtContrasena.Size = new System.Drawing.Size(356, 22);
            this.txtContrasena.TabIndex = 9;
            // 
            // txtCI
            // 
            this.txtCI.BackColor = System.Drawing.SystemColors.Info;
            this.txtCI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCI.Location = new System.Drawing.Point(245, 214);
            this.txtCI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(356, 22);
            this.txtCI.TabIndex = 8;
            // 
            // btnCrearUsuario
            // 
            this.btnCrearUsuario.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnCrearUsuario.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCrearUsuario.Location = new System.Drawing.Point(367, 468);
            this.btnCrearUsuario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCrearUsuario.Name = "btnCrearUsuario";
            this.btnCrearUsuario.Size = new System.Drawing.Size(139, 42);
            this.btnCrearUsuario.TabIndex = 6;
            this.btnCrearUsuario.Text = "Crear usuario";
            this.btnCrearUsuario.UseVisualStyleBackColor = false;
            this.btnCrearUsuario.Click += new System.EventHandler(this.btnCrearUsuario_Click);
            // 
            // lblConfirmarContraseña
            // 
            this.lblConfirmarContraseña.AutoSize = true;
            this.lblConfirmarContraseña.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblConfirmarContraseña.Location = new System.Drawing.Point(245, 391);
            this.lblConfirmarContraseña.Name = "lblConfirmarContraseña";
            this.lblConfirmarContraseña.Size = new System.Drawing.Size(186, 25);
            this.lblConfirmarContraseña.TabIndex = 5;
            this.lblConfirmarContraseña.Text = "Confirmar contraseña:";
            // 
            // lblContraseña
            // 
            this.lblContraseña.AutoSize = true;
            this.lblContraseña.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblContraseña.Location = new System.Drawing.Point(245, 327);
            this.lblContraseña.Name = "lblContraseña";
            this.lblContraseña.Size = new System.Drawing.Size(105, 25);
            this.lblContraseña.TabIndex = 4;
            this.lblContraseña.Text = "Contraseña:";
            // 
            // lblNombreApellido
            // 
            this.lblNombreApellido.AutoSize = true;
            this.lblNombreApellido.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblNombreApellido.Location = new System.Drawing.Point(245, 135);
            this.lblNombreApellido.Name = "lblNombreApellido";
            this.lblNombreApellido.Size = new System.Drawing.Size(164, 25);
            this.lblNombreApellido.TabIndex = 3;
            this.lblNombreApellido.Text = "Nombre y apellido:";
            // 
            // lblCI
            // 
            this.lblCI.AutoSize = true;
            this.lblCI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblCI.Location = new System.Drawing.Point(245, 192);
            this.lblCI.Name = "lblCI";
            this.lblCI.Size = new System.Drawing.Size(32, 25);
            this.lblCI.TabIndex = 2;
            this.lblCI.Text = "CI:";
            // 
            // lblInfoCuenta
            // 
            this.lblInfoCuenta.AutoSize = true;
            this.lblInfoCuenta.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold);
            this.lblInfoCuenta.Location = new System.Drawing.Point(273, 90);
            this.lblInfoCuenta.Name = "lblInfoCuenta";
            this.lblInfoCuenta.Size = new System.Drawing.Size(314, 38);
            this.lblInfoCuenta.TabIndex = 1;
            this.lblInfoCuenta.Text = "Información de cuenta";
            // 
            // pnlEncabezadoCrearCuenta
            // 
            this.pnlEncabezadoCrearCuenta.BackColor = System.Drawing.Color.LightGray;
            this.pnlEncabezadoCrearCuenta.Controls.Add(this.lblEncabezadoRegistro);
            this.pnlEncabezadoCrearCuenta.Location = new System.Drawing.Point(-1, -1);
            this.pnlEncabezadoCrearCuenta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlEncabezadoCrearCuenta.Name = "pnlEncabezadoCrearCuenta";
            this.pnlEncabezadoCrearCuenta.Size = new System.Drawing.Size(847, 75);
            this.pnlEncabezadoCrearCuenta.TabIndex = 0;
            // 
            // lblEncabezadoRegistro
            // 
            this.lblEncabezadoRegistro.AutoSize = true;
            this.lblEncabezadoRegistro.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold);
            this.lblEncabezadoRegistro.Location = new System.Drawing.Point(197, 19);
            this.lblEncabezadoRegistro.Name = "lblEncabezadoRegistro";
            this.lblEncabezadoRegistro.Size = new System.Drawing.Size(466, 45);
            this.lblEncabezadoRegistro.TabIndex = 0;
            this.lblEncabezadoRegistro.Text = "CREAR UNA NUEVA CUENTA";
            // 
            // tabPageInicioSesion
            // 
            this.tabPageInicioSesion.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPageInicioSesion.Controls.Add(this.pnlCuerpoTitulo);
            this.tabPageInicioSesion.Controls.Add(this.pictureBoxLogin);
            this.tabPageInicioSesion.Location = new System.Drawing.Point(4, 25);
            this.tabPageInicioSesion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageInicioSesion.Name = "tabPageInicioSesion";
            this.tabPageInicioSesion.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageInicioSesion.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPageInicioSesion.Size = new System.Drawing.Size(1379, 661);
            this.tabPageInicioSesion.TabIndex = 0;
            this.tabPageInicioSesion.Text = "Usuario";
            // 
            // pnlCuerpoTitulo
            // 
            this.pnlCuerpoTitulo.BackColor = System.Drawing.Color.White;
            this.pnlCuerpoTitulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCuerpoTitulo.Controls.Add(this.linkLabelEliminarCuenta);
            this.pnlCuerpoTitulo.Controls.Add(this.linkLblContraseñaOlvidada);
            this.pnlCuerpoTitulo.Controls.Add(this.pictureBoxLogoSesion);
            this.pnlCuerpoTitulo.Controls.Add(this.txtContrasenaLogin);
            this.pnlCuerpoTitulo.Controls.Add(this.txtCILogin);
            this.pnlCuerpoTitulo.Controls.Add(this.lblContrasenaLogin);
            this.pnlCuerpoTitulo.Controls.Add(this.lblCILogin);
            this.pnlCuerpoTitulo.Controls.Add(this.btnAcceder);
            this.pnlCuerpoTitulo.Controls.Add(this.pnInicioTitulo);
            this.pnlCuerpoTitulo.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.pnlCuerpoTitulo.Location = new System.Drawing.Point(806, 76);
            this.pnlCuerpoTitulo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlCuerpoTitulo.Name = "pnlCuerpoTitulo";
            this.pnlCuerpoTitulo.Size = new System.Drawing.Size(487, 526);
            this.pnlCuerpoTitulo.TabIndex = 2;
            // 
            // linkLblContraseñaOlvidada
            // 
            this.linkLblContraseñaOlvidada.AutoSize = true;
            this.linkLblContraseñaOlvidada.Location = new System.Drawing.Point(142, 380);
            this.linkLblContraseñaOlvidada.Name = "linkLblContraseñaOlvidada";
            this.linkLblContraseñaOlvidada.Size = new System.Drawing.Size(195, 25);
            this.linkLblContraseñaOlvidada.TabIndex = 6;
            this.linkLblContraseñaOlvidada.TabStop = true;
            this.linkLblContraseñaOlvidada.Text = "¿Ólvido su contraseña?";
            this.linkLblContraseñaOlvidada.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLblContraseñaOlvidada_LinkClicked);
            // 
            // pictureBoxLogoSesion
            // 
            this.pictureBoxLogoSesion.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxLogoSesion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogoSesion.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogoSesion.Image")));
            this.pictureBoxLogoSesion.Location = new System.Drawing.Point(198, 80);
            this.pictureBoxLogoSesion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBoxLogoSesion.Name = "pictureBoxLogoSesion";
            this.pictureBoxLogoSesion.Size = new System.Drawing.Size(108, 108);
            this.pictureBoxLogoSesion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogoSesion.TabIndex = 5;
            this.pictureBoxLogoSesion.TabStop = false;
            // 
            // txtContrasenaLogin
            // 
            this.txtContrasenaLogin.BackColor = System.Drawing.SystemColors.Info;
            this.txtContrasenaLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContrasenaLogin.Location = new System.Drawing.Point(40, 331);
            this.txtContrasenaLogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtContrasenaLogin.Multiline = true;
            this.txtContrasenaLogin.Name = "txtContrasenaLogin";
            this.txtContrasenaLogin.PasswordChar = '*';
            this.txtContrasenaLogin.Size = new System.Drawing.Size(409, 33);
            this.txtContrasenaLogin.TabIndex = 4;
            // 
            // txtCILogin
            // 
            this.txtCILogin.BackColor = System.Drawing.SystemColors.Info;
            this.txtCILogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCILogin.Location = new System.Drawing.Point(40, 236);
            this.txtCILogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCILogin.Multiline = true;
            this.txtCILogin.Name = "txtCILogin";
            this.txtCILogin.Size = new System.Drawing.Size(409, 33);
            this.txtCILogin.TabIndex = 3;
            // 
            // lblContrasenaLogin
            // 
            this.lblContrasenaLogin.AutoSize = true;
            this.lblContrasenaLogin.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblContrasenaLogin.Location = new System.Drawing.Point(40, 294);
            this.lblContrasenaLogin.Name = "lblContrasenaLogin";
            this.lblContrasenaLogin.Size = new System.Drawing.Size(105, 25);
            this.lblContrasenaLogin.TabIndex = 2;
            this.lblContrasenaLogin.Text = "Contraseña:";
            // 
            // lblCILogin
            // 
            this.lblCILogin.AutoSize = true;
            this.lblCILogin.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblCILogin.Location = new System.Drawing.Point(40, 195);
            this.lblCILogin.Name = "lblCILogin";
            this.lblCILogin.Size = new System.Drawing.Size(32, 25);
            this.lblCILogin.TabIndex = 1;
            this.lblCILogin.Text = "CI:";
            // 
            // btnAcceder
            // 
            this.btnAcceder.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnAcceder.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAcceder.Location = new System.Drawing.Point(40, 419);
            this.btnAcceder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAcceder.Name = "btnAcceder";
            this.btnAcceder.Size = new System.Drawing.Size(409, 42);
            this.btnAcceder.TabIndex = 0;
            this.btnAcceder.Text = "Acceder";
            this.btnAcceder.UseVisualStyleBackColor = false;
            this.btnAcceder.Click += new System.EventHandler(this.btnAcceder_Click);
            // 
            // pnInicioTitulo
            // 
            this.pnInicioTitulo.BackColor = System.Drawing.Color.LightGray;
            this.pnInicioTitulo.Controls.Add(this.lblinicio);
            this.pnInicioTitulo.Location = new System.Drawing.Point(-1, -1);
            this.pnInicioTitulo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnInicioTitulo.Name = "pnInicioTitulo";
            this.pnInicioTitulo.Size = new System.Drawing.Size(487, 64);
            this.pnInicioTitulo.TabIndex = 0;
            // 
            // lblinicio
            // 
            this.lblinicio.AutoSize = true;
            this.lblinicio.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.lblinicio.Location = new System.Drawing.Point(84, 21);
            this.lblinicio.Name = "lblinicio";
            this.lblinicio.Size = new System.Drawing.Size(341, 31);
            this.lblinicio.TabIndex = 1;
            this.lblinicio.Text = "INICIO DE SESIÓN AL SISTEMA";
            // 
            // pictureBoxLogin
            // 
            this.pictureBoxLogin.BackColor = System.Drawing.SystemColors.Info;
            this.pictureBoxLogin.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogin.Image")));
            this.pictureBoxLogin.Location = new System.Drawing.Point(-4, 0);
            this.pictureBoxLogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBoxLogin.Name = "pictureBoxLogin";
            this.pictureBoxLogin.Size = new System.Drawing.Size(689, 661);
            this.pictureBoxLogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogin.TabIndex = 1;
            this.pictureBoxLogin.TabStop = false;
            // 
            // tabControlUsuario
            // 
            this.tabControlUsuario.Controls.Add(this.tabPageInicioSesion);
            this.tabControlUsuario.Controls.Add(this.tabPageCrearNuevaCuenta);
            this.tabControlUsuario.Controls.Add(this.Actualizar);
            this.tabControlUsuario.Controls.Add(this.tabPageADMIN);
            this.tabControlUsuario.Location = new System.Drawing.Point(-2, -1);
            this.tabControlUsuario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControlUsuario.Name = "tabControlUsuario";
            this.tabControlUsuario.SelectedIndex = 0;
            this.tabControlUsuario.Size = new System.Drawing.Size(1387, 690);
            this.tabControlUsuario.TabIndex = 3;
            // 
            // Actualizar
            // 
            this.Actualizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Actualizar.BackgroundImage")));
            this.Actualizar.Controls.Add(this.pnlActualizar);
            this.Actualizar.Location = new System.Drawing.Point(4, 25);
            this.Actualizar.Name = "Actualizar";
            this.Actualizar.Size = new System.Drawing.Size(1379, 661);
            this.Actualizar.TabIndex = 0;
            this.Actualizar.Text = "Actualizar";
            this.Actualizar.UseVisualStyleBackColor = true;
            // 
            // pnlActualizar
            // 
            this.pnlActualizar.BackColor = System.Drawing.Color.White;
            this.pnlActualizar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActualizar.Controls.Add(this.btnBuscar);
            this.pnlActualizar.Controls.Add(this.button2);
            this.pnlActualizar.Controls.Add(this.btnActualizar);
            this.pnlActualizar.Controls.Add(this.txtActualizarEmail);
            this.pnlActualizar.Controls.Add(this.lblActualizarEmail);
            this.pnlActualizar.Controls.Add(this.txtActualizarNYA);
            this.pnlActualizar.Controls.Add(this.txtActualizarConfirmarContrasena);
            this.pnlActualizar.Controls.Add(this.txtActualizarContrasena);
            this.pnlActualizar.Controls.Add(this.txtBuscarCI);
            this.pnlActualizar.Controls.Add(this.lblActualizarConfirmarContrasena);
            this.pnlActualizar.Controls.Add(this.lblActualizarContrasena);
            this.pnlActualizar.Controls.Add(this.lblActualizarNombreYApellido);
            this.pnlActualizar.Controls.Add(this.lblActualizarCI);
            this.pnlActualizar.Controls.Add(this.lblActualizarInfo);
            this.pnlActualizar.Controls.Add(this.pnlActualziar1);
            this.pnlActualizar.Location = new System.Drawing.Point(266, 48);
            this.pnlActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlActualizar.Name = "pnlActualizar";
            this.pnlActualizar.Size = new System.Drawing.Size(847, 564);
            this.pnlActualizar.TabIndex = 2;
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnBuscar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBuscar.Location = new System.Drawing.Point(369, 93);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(140, 42);
            this.btnBuscar.TabIndex = 16;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnActualizar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnActualizar.Location = new System.Drawing.Point(369, 493);
            this.btnActualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(140, 42);
            this.btnActualizar.TabIndex = 15;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = false;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // txtActualizarEmail
            // 
            this.txtActualizarEmail.BackColor = System.Drawing.SystemColors.Info;
            this.txtActualizarEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtActualizarEmail.Location = new System.Drawing.Point(277, 319);
            this.txtActualizarEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtActualizarEmail.Name = "txtActualizarEmail";
            this.txtActualizarEmail.Size = new System.Drawing.Size(307, 22);
            this.txtActualizarEmail.TabIndex = 14;
            // 
            // lblActualizarEmail
            // 
            this.lblActualizarEmail.AutoSize = true;
            this.lblActualizarEmail.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblActualizarEmail.Location = new System.Drawing.Point(272, 283);
            this.lblActualizarEmail.Name = "lblActualizarEmail";
            this.lblActualizarEmail.Size = new System.Drawing.Size(65, 25);
            this.lblActualizarEmail.TabIndex = 13;
            this.lblActualizarEmail.Text = "E-mail:";
            // 
            // txtActualizarNYA
            // 
            this.txtActualizarNYA.BackColor = System.Drawing.SystemColors.Info;
            this.txtActualizarNYA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtActualizarNYA.Location = new System.Drawing.Point(277, 248);
            this.txtActualizarNYA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtActualizarNYA.Name = "txtActualizarNYA";
            this.txtActualizarNYA.Size = new System.Drawing.Size(307, 22);
            this.txtActualizarNYA.TabIndex = 11;
            // 
            // txtActualizarConfirmarContrasena
            // 
            this.txtActualizarConfirmarContrasena.BackColor = System.Drawing.SystemColors.Info;
            this.txtActualizarConfirmarContrasena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtActualizarConfirmarContrasena.Location = new System.Drawing.Point(277, 457);
            this.txtActualizarConfirmarContrasena.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtActualizarConfirmarContrasena.Name = "txtActualizarConfirmarContrasena";
            this.txtActualizarConfirmarContrasena.PasswordChar = '*';
            this.txtActualizarConfirmarContrasena.Size = new System.Drawing.Size(307, 22);
            this.txtActualizarConfirmarContrasena.TabIndex = 10;
            // 
            // txtActualizarContrasena
            // 
            this.txtActualizarContrasena.BackColor = System.Drawing.SystemColors.Info;
            this.txtActualizarContrasena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtActualizarContrasena.Location = new System.Drawing.Point(277, 388);
            this.txtActualizarContrasena.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtActualizarContrasena.Name = "txtActualizarContrasena";
            this.txtActualizarContrasena.PasswordChar = '*';
            this.txtActualizarContrasena.Size = new System.Drawing.Size(307, 22);
            this.txtActualizarContrasena.TabIndex = 9;
            // 
            // txtBuscarCI
            // 
            this.txtBuscarCI.BackColor = System.Drawing.SystemColors.Info;
            this.txtBuscarCI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBuscarCI.Location = new System.Drawing.Point(161, 104);
            this.txtBuscarCI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBuscarCI.Name = "txtBuscarCI";
            this.txtBuscarCI.Size = new System.Drawing.Size(189, 22);
            this.txtBuscarCI.TabIndex = 8;
            // 
            // lblActualizarConfirmarContrasena
            // 
            this.lblActualizarConfirmarContrasena.AutoSize = true;
            this.lblActualizarConfirmarContrasena.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblActualizarConfirmarContrasena.Location = new System.Drawing.Point(272, 430);
            this.lblActualizarConfirmarContrasena.Name = "lblActualizarConfirmarContrasena";
            this.lblActualizarConfirmarContrasena.Size = new System.Drawing.Size(186, 25);
            this.lblActualizarConfirmarContrasena.TabIndex = 5;
            this.lblActualizarConfirmarContrasena.Text = "Confirmar contraseña:";
            // 
            // lblActualizarContrasena
            // 
            this.lblActualizarContrasena.AutoSize = true;
            this.lblActualizarContrasena.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblActualizarContrasena.Location = new System.Drawing.Point(272, 361);
            this.lblActualizarContrasena.Name = "lblActualizarContrasena";
            this.lblActualizarContrasena.Size = new System.Drawing.Size(105, 25);
            this.lblActualizarContrasena.TabIndex = 4;
            this.lblActualizarContrasena.Text = "Contraseña:";
            // 
            // lblActualizarNombreYApellido
            // 
            this.lblActualizarNombreYApellido.AutoSize = true;
            this.lblActualizarNombreYApellido.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblActualizarNombreYApellido.Location = new System.Drawing.Point(272, 211);
            this.lblActualizarNombreYApellido.Name = "lblActualizarNombreYApellido";
            this.lblActualizarNombreYApellido.Size = new System.Drawing.Size(164, 25);
            this.lblActualizarNombreYApellido.TabIndex = 3;
            this.lblActualizarNombreYApellido.Text = "Nombre y apellido:";
            // 
            // lblActualizarCI
            // 
            this.lblActualizarCI.AutoSize = true;
            this.lblActualizarCI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.lblActualizarCI.Location = new System.Drawing.Point(37, 99);
            this.lblActualizarCI.Name = "lblActualizarCI";
            this.lblActualizarCI.Size = new System.Drawing.Size(118, 25);
            this.lblActualizarCI.TabIndex = 2;
            this.lblActualizarCI.Text = "Ingrese su CI:";
            // 
            // lblActualizarInfo
            // 
            this.lblActualizarInfo.AutoSize = true;
            this.lblActualizarInfo.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold);
            this.lblActualizarInfo.Location = new System.Drawing.Point(270, 164);
            this.lblActualizarInfo.Name = "lblActualizarInfo";
            this.lblActualizarInfo.Size = new System.Drawing.Size(314, 38);
            this.lblActualizarInfo.TabIndex = 1;
            this.lblActualizarInfo.Text = "Información de cuenta";
            // 
            // pnlActualziar1
            // 
            this.pnlActualziar1.BackColor = System.Drawing.Color.LightGray;
            this.pnlActualziar1.Controls.Add(this.lblActualizar);
            this.pnlActualziar1.Location = new System.Drawing.Point(-1, -1);
            this.pnlActualziar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlActualziar1.Name = "pnlActualziar1";
            this.pnlActualziar1.Size = new System.Drawing.Size(847, 75);
            this.pnlActualziar1.TabIndex = 0;
            // 
            // lblActualizar
            // 
            this.lblActualizar.AutoSize = true;
            this.lblActualizar.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold);
            this.lblActualizar.Location = new System.Drawing.Point(265, 15);
            this.lblActualizar.Name = "lblActualizar";
            this.lblActualizar.Size = new System.Drawing.Size(337, 45);
            this.lblActualizar.TabIndex = 0;
            this.lblActualizar.Text = "ACTUALIZAR DATOS";
            // 
            // tabPageADMIN
            // 
            this.tabPageADMIN.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPageADMIN.Controls.Add(this.lblAdmin);
            this.tabPageADMIN.Controls.Add(this.panel1);
            this.tabPageADMIN.Location = new System.Drawing.Point(4, 25);
            this.tabPageADMIN.Name = "tabPageADMIN";
            this.tabPageADMIN.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageADMIN.Size = new System.Drawing.Size(1379, 661);
            this.tabPageADMIN.TabIndex = 2;
            this.tabPageADMIN.Text = "Administrador";
            // 
            // lblAdmin
            // 
            this.lblAdmin.AutoSize = true;
            this.lblAdmin.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmin.Location = new System.Drawing.Point(471, 43);
            this.lblAdmin.Name = "lblAdmin";
            this.lblAdmin.Size = new System.Drawing.Size(412, 45);
            this.lblAdmin.TabIndex = 2;
            this.lblAdmin.Text = "PERSONAL AUTORIZADO";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.txtADMINContrasena);
            this.panel1.Controls.Add(this.txtADMINCI);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnAccederADMIN);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.panel1.Location = new System.Drawing.Point(433, 119);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(487, 462);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(198, 80);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(108, 108);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // txtADMINContrasena
            // 
            this.txtADMINContrasena.BackColor = System.Drawing.SystemColors.Info;
            this.txtADMINContrasena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtADMINContrasena.Location = new System.Drawing.Point(40, 331);
            this.txtADMINContrasena.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtADMINContrasena.Multiline = true;
            this.txtADMINContrasena.Name = "txtADMINContrasena";
            this.txtADMINContrasena.PasswordChar = '*';
            this.txtADMINContrasena.Size = new System.Drawing.Size(409, 33);
            this.txtADMINContrasena.TabIndex = 4;
            // 
            // txtADMINCI
            // 
            this.txtADMINCI.BackColor = System.Drawing.SystemColors.Info;
            this.txtADMINCI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtADMINCI.Location = new System.Drawing.Point(40, 236);
            this.txtADMINCI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtADMINCI.Multiline = true;
            this.txtADMINCI.Name = "txtADMINCI";
            this.txtADMINCI.Size = new System.Drawing.Size(409, 33);
            this.txtADMINCI.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.label1.Location = new System.Drawing.Point(40, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Contraseña:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.label2.Location = new System.Drawing.Point(40, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "CI:";
            // 
            // btnAccederADMIN
            // 
            this.btnAccederADMIN.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnAccederADMIN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAccederADMIN.Location = new System.Drawing.Point(40, 398);
            this.btnAccederADMIN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAccederADMIN.Name = "btnAccederADMIN";
            this.btnAccederADMIN.Size = new System.Drawing.Size(409, 42);
            this.btnAccederADMIN.TabIndex = 0;
            this.btnAccederADMIN.Text = "Acceder";
            this.btnAccederADMIN.UseVisualStyleBackColor = false;
            this.btnAccederADMIN.Click += new System.EventHandler(this.btnAccederADMIN_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(-1, -1);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(487, 64);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(86, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(341, 31);
            this.label3.TabIndex = 1;
            this.label3.Text = "INICIO DE SESIÓN AL SISTEMA";
            // 
            // toolTip2
            // 
            this.toolTip2.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // linkLabelEliminarCuenta
            // 
            this.linkLabelEliminarCuenta.AutoSize = true;
            this.linkLabelEliminarCuenta.Location = new System.Drawing.Point(184, 487);
            this.linkLabelEliminarCuenta.Name = "linkLabelEliminarCuenta";
            this.linkLabelEliminarCuenta.Size = new System.Drawing.Size(131, 25);
            this.linkLabelEliminarCuenta.TabIndex = 7;
            this.linkLabelEliminarCuenta.TabStop = true;
            this.linkLabelEliminarCuenta.Text = "Eliminar cuenta";
            this.linkLabelEliminarCuenta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelEliminarCuenta_LinkClicked);
            // 
            // FrmLoginUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1383, 689);
            this.Controls.Add(this.tabControlUsuario);
            this.Name = "FrmLoginUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GRUPO A";
            this.tabPageCrearNuevaCuenta.ResumeLayout(false);
            this.pnlCrearCuenta.ResumeLayout(false);
            this.pnlCrearCuenta.PerformLayout();
            this.pnlEncabezadoCrearCuenta.ResumeLayout(false);
            this.pnlEncabezadoCrearCuenta.PerformLayout();
            this.tabPageInicioSesion.ResumeLayout(false);
            this.pnlCuerpoTitulo.ResumeLayout(false);
            this.pnlCuerpoTitulo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogoSesion)).EndInit();
            this.pnInicioTitulo.ResumeLayout(false);
            this.pnInicioTitulo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogin)).EndInit();
            this.tabControlUsuario.ResumeLayout(false);
            this.Actualizar.ResumeLayout(false);
            this.pnlActualizar.ResumeLayout(false);
            this.pnlActualizar.PerformLayout();
            this.pnlActualziar1.ResumeLayout(false);
            this.pnlActualziar1.PerformLayout();
            this.tabPageADMIN.ResumeLayout(false);
            this.tabPageADMIN.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TabPage tabPageCrearNuevaCuenta;
        private System.Windows.Forms.Panel pnlCrearCuenta;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.Button btnInfoContrasena;
        private System.Windows.Forms.TextBox txtNombreCuenta;
        private System.Windows.Forms.TextBox txtConfirmarContrasena;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.TextBox txtCI;
        private System.Windows.Forms.Button btnCrearUsuario;
        private System.Windows.Forms.Label lblConfirmarContraseña;
        private System.Windows.Forms.Label lblContraseña;
        private System.Windows.Forms.Label lblNombreApellido;
        private System.Windows.Forms.Label lblCI;
        private System.Windows.Forms.Label lblInfoCuenta;
        private System.Windows.Forms.Panel pnlEncabezadoCrearCuenta;
        private System.Windows.Forms.Label lblEncabezadoRegistro;
        private System.Windows.Forms.TabPage tabPageInicioSesion;
        private System.Windows.Forms.Panel pnlCuerpoTitulo;
        private System.Windows.Forms.LinkLabel linkLblContraseñaOlvidada;
        private System.Windows.Forms.PictureBox pictureBoxLogoSesion;
        private System.Windows.Forms.TextBox txtContrasenaLogin;
        private System.Windows.Forms.Label lblContrasenaLogin;
        private System.Windows.Forms.Label lblCILogin;
        private System.Windows.Forms.Button btnAcceder;
        private System.Windows.Forms.Panel pnInicioTitulo;
        private System.Windows.Forms.Label lblinicio;
        private System.Windows.Forms.PictureBox pictureBoxLogin;
        private System.Windows.Forms.TabControl tabControlUsuario;
        private System.Windows.Forms.TabPage Actualizar;
        private System.Windows.Forms.Panel pnlActualizar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.TextBox txtActualizarEmail;
        private System.Windows.Forms.Label lblActualizarEmail;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtActualizarNYA;
        private System.Windows.Forms.TextBox txtActualizarConfirmarContrasena;
        private System.Windows.Forms.TextBox txtActualizarContrasena;
        private System.Windows.Forms.TextBox txtBuscarCI;
        private System.Windows.Forms.Label lblActualizarConfirmarContrasena;
        private System.Windows.Forms.Label lblActualizarContrasena;
        private System.Windows.Forms.Label lblActualizarNombreYApellido;
        private System.Windows.Forms.Label lblActualizarCI;
        private System.Windows.Forms.Label lblActualizarInfo;
        private System.Windows.Forms.Panel pnlActualziar1;
        private System.Windows.Forms.Label lblActualizar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.TabPage tabPageADMIN;
        private System.Windows.Forms.Label lblAdmin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtADMINContrasena;
        private System.Windows.Forms.TextBox txtADMINCI;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAccederADMIN;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtCILogin;
        private System.Windows.Forms.LinkLabel linkLabelEliminarCuenta;
    }
}