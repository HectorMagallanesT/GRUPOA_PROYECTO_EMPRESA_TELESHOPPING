﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CapaDatos;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class FrmModulos : Form
    {
    
        private List<CN_ProductosCarrito> productosEnCarrito = new List<CN_ProductosCarrito>();
        public event Action<CN_ProductosCarrito> ProductoAgregadoAlCarrito;

        // Variable para acceder a la capa de datos usuarioD
        private ModulosD ModulosD;

        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";


        /// <summary>
        /// Constructor del formulario que recibe el número de cédula del usuario.
        /// </summary>
        /// <param name="ci">Número de cédula del usuario.</param>
        public FrmModulos(string ci )
        {
            InitializeComponent(); //Inicializa el formulario

            // Crear una instancia de la clase UsuarioD con la cadena de conexión
            ModulosD = new ModulosD(connectionString);

            // Obtener el campo NombreYApellido de la base de datos en base al CI
            string nombreApellido = ModulosD.ObtenerNombreYApellido(ci);

            // Mostrar el nombre y apellido en el TextBox correspondiente
            labelNombreYApellido.Text = nombreApellido;
          
        }

        /// <summary>
        /// Obtiene el nombre y apellido del usuario.
        /// </summary>
        /// <returns>Nombre y apellido del usuario.</returns>
        public string NombreYApellido
        {
            get { return labelNombreYApellido.Text; }
        }


        /// <summary>
        /// Manejador del evento que se activa al hacer clic en el menú "Catálogo de Productos".
        /// Abre el formulario de consulta de catálogo y pasa el nombre y apellido del usuario.
        /// </summary>
        private void catalogoDeProductosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            string nombreYApellido = ObtenerNombreYApellido(); // Obtén el valor del Label en FrmModulos

            Form miFormulario = new frmConsultaCatalogo(nombreYApellido); // Pasa el valor como argumento al constructor
            miFormulario.MdiParent = this;
            miFormulario.BringToFront();
            miFormulario.Show();

        }

        /// <summary>
        /// Obtiene el nombre y apellido del usuario.
        /// </summary>
        /// <returns>Nombre y apellido del usuario.</returns>
        public string ObtenerNombreYApellido()
        {
            return labelNombreYApellido.Text;
        }

        /// <summary>
        /// Manejador del evento que se activa al hacer clic en el menú "P".
        /// Crea una instancia del formulario FrmCarritoA, pasa el nombre y apellido del usuario,
        /// establece este formulario como el formulario principal del MdiParent y lo muestra.
        /// Además, hace visibles los botones en el formulario FrmCarritoA.
        /// </summary>
        private void pToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Obtener el nombre y apellido del cliente (puedes obtenerlo de alguna manera)
            string nombreYApellido = ObtenerNombreYApellido();

            // Crear una instancia del formulario FrmCarritoA y pasar el nombre y apellido
            FrmCarritoA carritoForm = new FrmCarritoA(nombreYApellido);

            carritoForm.MdiParent = this;
            carritoForm.BringToFront();

            // Hacer visibles los botones en el formulario FrmCarritoA
            carritoForm.HacerBotonesVisibles();

            // Mostrar el formulario
            carritoForm.Show();   

        }

        /// <summary>
        /// Manejador del evento que se activa al hacer clic en el menú "Orden de Compra Generada".
        /// Abre el formulario de Orden de Pago y pasa el nombre y apellido del usuario.
        /// </summary>
        private void ordenDeCompraGeneradaToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            // Obtén el nombre y apellido del labelNombreYApellido
            string nombreYApellido = NombreYApellido;

            // Crea una instancia de FrmOrdenDePago y pásale el nombre y apellido
            FrmOrdenDePago frmOrdenDePago = new FrmOrdenDePago(nombreYApellido);

            frmOrdenDePago.MdiParent = this;
            frmOrdenDePago.BringToFront();
            frmOrdenDePago.Show();
        }

      
    }

}
