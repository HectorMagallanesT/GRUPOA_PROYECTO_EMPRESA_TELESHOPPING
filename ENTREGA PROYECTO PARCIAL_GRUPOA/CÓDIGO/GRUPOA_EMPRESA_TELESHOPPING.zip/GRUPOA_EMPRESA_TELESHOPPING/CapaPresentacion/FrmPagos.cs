﻿
using CapaNegocio;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmPagos : Form
    {
        private UsuarioNegocio usuarioNegocio;


        /// <summary>
        /// Constructor del formulario.
        /// Inicializa el formulario y crea una instancia de la clase UsuarioNegocio con la cadena de conexión.
        /// </summary>
        public FrmPagos()
        {
            InitializeComponent();
            string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";
            usuarioNegocio = new UsuarioNegocio(connectionString);
        }


        /// <summary>
        /// Manejador del evento que se activa al cambiar el texto en el cuadro de texto de CI.
        /// Realiza una búsqueda de usuario por CI y muestra los datos si se encuentra.
        /// </summary>
        private void txtCI_TextChanged(object sender, EventArgs e)
        {
            string ci = txtCI.Text;
            DataTable dataTable = usuarioNegocio.BuscarUsuarioPorCIPago(ci);

            if (dataTable.Rows.Count > 0)
            {
                txtNombreYApellido.Text = dataTable.Rows[0]["nombreYApellido"].ToString();
                txtEmail.Text = dataTable.Rows[0]["email"].ToString();
            }
            else
            {
                txtNombreYApellido.Text = "";
                txtEmail.Text = "";
            }
        }

        /// <summary>
        /// Manejador del evento que se activa al cambiar el texto en el cuadro de texto de Nombre y Apellido.
        /// Calcula el total del carrito en función del usuario actual.
        /// </summary>
        private void txtNombreYApellido_TextChanged(object sender, EventArgs e)
        {
            CalcularTotalCarrito();
        }

        /// <summary>
        /// Manejador del evento que se activa al hacer clic en el botón "Generar Orden".
        /// Realiza la generación de una orden de compra, valida los datos y elimina los registros del carrito.
        /// </summary>
        private void btnGenerarOrden_Click(object sender, EventArgs e)
        {
            if (!ValidarCI())
            {
                MessageBox.Show("El número de CI debe tener 10 dígitos numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(txtNombreYApellido.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtDireccion.Text) ||
                string.IsNullOrEmpty(txtTelf.Text) || string.IsNullOrEmpty(txtTotal.Text) || cbxMetodosPago.SelectedItem == null)
            {
                MessageBox.Show("Falta por completar información.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal total;
            if (decimal.TryParse(txtTotal.Text, out total))
            {
                string ci = txtCI.Text;
                string nombreYApellido = txtNombreYApellido.Text;
                string email = txtEmail.Text;
                string direccion = txtDireccion.Text;
                string telefono = txtTelf.Text;
                string metodoPago = cbxMetodosPago.SelectedItem.ToString();
                DateTime fechaHora = dateTimePicker1.Value;

                usuarioNegocio.RealizarPago(ci, nombreYApellido, email, direccion, telefono, metodoPago, fechaHora, total);
                usuarioNegocio.EliminarRegistrosCarrito();  // Aquí eliminamos los registros de la tabla CarritoCompras

                MessageBox.Show("Orden de compra generada con éxito. Carrito de compras vaciado.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos();
                this.Close();
            }
            else
            {
                MessageBox.Show("El valor de Total no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Valida si el número de CI tiene el formato correcto.
        /// </summary>
        /// <returns>True si el formato es válido, de lo contrario, False.</returns>
        private bool ValidarCI()
        {
            if (txtCI.Text.Length != 10)
            {
                return false;
            }

            if (!int.TryParse(txtCI.Text, out _))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Limpia los campos de entrada de datos.
        /// </summary>
        private void LimpiarCampos()
        {
            txtCI.Text = "";
            txtNombreYApellido.Text = "";
            txtEmail.Text = "";
            txtDireccion.Text = "";
            txtTelf.Text = "";
            cbxMetodosPago.SelectedIndex = -1;
            dateTimePicker1.Value = DateTime.Now;
            txtTotal.Text = "";
        }


        /// <summary>
        /// Calcula el total del carrito de compras en función del usuario actual.
        /// </summary>
        private void CalcularTotalCarrito()
        {
            string nombreUsuario = txtNombreYApellido.Text;

            // Realizar la consulta SQL para calcular el total del carrito para el usuario actual
            string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("SELECT SUM(TotalAPagar) FROM CarritoCompras WHERE NombreUsuario = @NombreUsuario", connection))
                {
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);

                    object result = command.ExecuteScalar();

                    if (result != DBNull.Value)
                    {
                        txtTotal.Text = result.ToString();
                    }
                    else
                    {
                        txtTotal.Text = "0.00";
                    }
                }
            }
        }
    }
}
