﻿namespace CapaPresentacion
{
    partial class FrmCarritoA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dgvProductosC = new System.Windows.Forms.DataGridView();
            this.btnPago = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductosC)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(371, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Carrito de compras";
            // 
            // dgvProductosC
            // 
            this.dgvProductosC.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvProductosC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvProductosC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductosC.Location = new System.Drawing.Point(80, 73);
            this.dgvProductosC.Name = "dgvProductosC";
            this.dgvProductosC.RowHeadersWidth = 51;
            this.dgvProductosC.RowTemplate.Height = 24;
            this.dgvProductosC.Size = new System.Drawing.Size(749, 352);
            this.dgvProductosC.TabIndex = 2;
            // 
            // btnPago
            // 
            this.btnPago.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPago.Location = new System.Drawing.Point(402, 457);
            this.btnPago.Name = "btnPago";
            this.btnPago.Size = new System.Drawing.Size(164, 40);
            this.btnPago.TabIndex = 4;
            this.btnPago.Text = "Finalizar Compra";
            this.btnPago.UseVisualStyleBackColor = false;
            this.btnPago.Visible = false;
            this.btnPago.Click += new System.EventHandler(this.btnPago_Click);
            // 
            // FrmCarritoA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 524);
            this.Controls.Add(this.btnPago);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvProductosC);
            this.Name = "FrmCarritoA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carrito";
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductosC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvProductosC;
        private System.Windows.Forms.Button btnPago;
    }
}