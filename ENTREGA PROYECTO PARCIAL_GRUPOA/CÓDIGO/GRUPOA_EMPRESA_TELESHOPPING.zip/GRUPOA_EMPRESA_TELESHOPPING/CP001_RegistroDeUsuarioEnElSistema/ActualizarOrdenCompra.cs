﻿using NUnit.Framework;
using CapaNegocio;
using System;
using System.Data;

namespace Pruebas
{
    [TestFixture]
    public class ActualizarOrdenDeCompra
    {
        private OrdenDePagoN ordenDePagoN;

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            ordenDePagoN = new OrdenDePagoN();
        }

        [Test]
        public void ActualizarOrdenDeCompras()
        {
            // Configurar los parámetros para actualizar la orden de compra
            string ci = "0950678990";
            string nombreYApellido = "Hector Magallanes";
            string email = "hectorM08@gmail.com";
            string direccion = "Samanes y Pichincha22";
            string telf = "0989873454";
            string pago = "Efectivo";
            DateTime fechaHora = DateTime.Parse("2023-11-06 16:24:02.120");
            decimal total = 2.00m;

            // Intenta actualizar la orden de compra
            bool actualizacionExitosa = ordenDePagoN.ActualizarRegistro(ci, nombreYApellido, email, direccion, telf, pago, fechaHora, total);

            // Verifica que la actualización fue exitosa
            Assert.IsTrue(actualizacionExitosa, "La orden de compra no se actualizó correctamente.");
        }
    }
}
