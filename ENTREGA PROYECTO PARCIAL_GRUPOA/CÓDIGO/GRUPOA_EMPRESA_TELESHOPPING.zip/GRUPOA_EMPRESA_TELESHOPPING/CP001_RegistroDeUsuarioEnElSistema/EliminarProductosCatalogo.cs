﻿using CapaNegocio;
using CapaDatos;
using CapaPresentacion;
using NUnit.Framework;
using System.Data;

namespace Pruebas
{
    [TestFixture]
    public class EliminarProductoDelCatalogo
    {
        [Test]
        public void EliminarProductoDelCatalogoExitoso()
        {
            // Configura el ID del producto a eliminar
            int productoID = ObtenerIDProductoAEliminar();

            // Realiza la eliminación del producto
            CN_Productos productos = new CN_Productos();
            bool eliminacionExitosa = productos.EliminarProducto(productoID);

            // Verifica que la eliminación del producto sea exitosa
            Assert.IsTrue(eliminacionExitosa, "La eliminación del producto debería ser exitosa.");
        }

        private int ObtenerIDProductoAEliminar()
        {
            int productoID = 0; // Inicializa el ID del producto a cero o un valor por defecto.

            // Conecta a la base de datos utilizando la capa de datos o la clase CD_Productos
            CD_Productos productosDataAccess = new CD_Productos();

            // Realiza una consulta para obtener el ID del producto que se desea eliminar.
            string nombreProductoAEliminar = "medias";

            // Realiza la consulta para obtener el producto por su nombre
            DataTable resultado = productosDataAccess.BuscarProductosPorNombre(nombreProductoAEliminar);

            if (resultado.Rows.Count > 0)
            {
                // Si se encontró al menos un producto, obtiene el ID del primer producto encontrado.
                productoID = Convert.ToInt32(resultado.Rows[0]["ID"]); 
            }

            return productoID;
        }
    }
}
