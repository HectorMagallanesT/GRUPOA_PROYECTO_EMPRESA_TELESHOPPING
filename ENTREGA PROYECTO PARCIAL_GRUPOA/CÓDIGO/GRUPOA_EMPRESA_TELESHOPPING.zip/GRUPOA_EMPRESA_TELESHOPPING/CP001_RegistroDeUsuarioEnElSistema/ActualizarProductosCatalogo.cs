﻿using NUnit.Framework;
using CapaDatos; 


namespace Pruebas
{
    [TestFixture]
    public class ActualizarProductosCatalogo
    {
        private CD_Productos cdProductos; // instancia de la clase de acceso a datos.

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            cdProductos = new CD_Productos(); // Inicializar la clase de acceso a datos.
        }

        [Test]
        public void ActualizarProductoEnCatalogo()
        {
            // ID del producto que se desea actualizar 
            int productoID = ObtenerProductoID(); 

            // Realiza la actualización del producto utilizando la capa de datos.
            bool actualizacionExitosa = cdProductos.ModificarProducto(productoID, ObtenerBytesImagen(), "medias", "color blancas y negras", 2);

            // Verifica que la actualización haya sido exitosa.
            Assert.IsTrue(actualizacionExitosa, "La actualización del producto debería ser exitosa.");
        }

        // Función para obtener el ID del producto
        private int ObtenerProductoID()
        {
 
            return 1; 
        }

        // Función para obtener los bytes de la imagen, según tu escenario.
        private byte[] ObtenerBytesImagen()
        {
            // Cargamos la imagen desde la ruta especificada
            string rutaImagen = "C:\\Users\\hmaga\\Downloads\\Medias.jpg";

            if (File.Exists(rutaImagen))
            {
                // Leemos los bytes de la imagen desde el archivo
                byte[] bytesImagen = File.ReadAllBytes(rutaImagen);
                return bytesImagen;
            }
            else
            {
                // En caso de que la imagen no exista en la ruta especificada, puedes lanzar una excepción o manejar el error de alguna otra manera.
                throw new FileNotFoundException("La imagen no se encontró en la ruta especificada.");
            }
        }

    }
}
