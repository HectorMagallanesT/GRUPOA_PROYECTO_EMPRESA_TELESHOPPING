﻿using System;

namespace CapaException
{
    /// <summary>
    /// Excepción personalizada para manejar errores relacionados con la creación de usuarios.
    /// </summary>
    public class CrearUsuarioException : Exception
    {
        /// <summary>
        /// Inicializa una nueva instancia de la clase CrearUsuarioException.
        /// </summary>
        public CrearUsuarioException() : base() { }

        /// <summary>
        /// Inicializa una nueva instancia de la clase CrearUsuarioException con un mensaje de error personalizado.
        /// </summary>
        /// <param name="message">Mensaje de error personalizado.</param>
        public CrearUsuarioException(string message) : base(message) { }

        /// <summary>
        /// Inicializa una nueva instancia de la clase CrearUsuarioException con un mensaje de error personalizado
        /// y una excepción interna que causó esta excepción.
        /// </summary>
        /// <param name="message">Mensaje de error personalizado.</param>
        /// <param name="innerException">Excepción interna que causó esta excepción.</param>
        public CrearUsuarioException(string message, Exception innerException) : base(message, innerException) { }
    }
}
