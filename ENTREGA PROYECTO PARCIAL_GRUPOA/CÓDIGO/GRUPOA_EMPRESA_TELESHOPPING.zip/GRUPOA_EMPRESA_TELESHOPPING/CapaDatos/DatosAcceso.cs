﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class DatosAcceso
    {
        private string connectionString;

        /// <summary>
        /// Constructor de la clase DatosAcceso.
        /// </summary>
        /// <param name="connectionString">Cadena de conexión a la base de datos.</param>
        public DatosAcceso(string connectionString)
        {
            this.connectionString = connectionString;
        }


        /// <summary>
        /// Busca un usuario en la base de datos por su número de cédula de identidad (CI).
        /// </summary>
        /// <param name="ci">Número de cédula de identidad (CI) del usuario a buscar.</param>
        /// <returns>Un DataTable con la información del usuario encontrado o un DataTable vacío si no se encuentra ningún usuario con el CI proporcionado.</returns>
        public DataTable BuscarUsuarioPorCI(string ci)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("sp_BuscarUsuarioPorCI", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CI", ci);
                    DataTable dataTable = new DataTable();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                    return dataTable;
                }
            }
        }

        // <summary>
        /// Realiza un registro de pago en la base de datos.
        /// </summary>
        /// <param name="ci">Número de cédula de identidad (CI) del usuario que realiza el pago.</param>
        /// <param name="nombreYApellido">Nombre y apellidos del usuario que realiza el pago.</param>
        /// <param name="email">Dirección de correo electrónico del usuario que realiza el pago.</param>
        /// <param name="direccion">Dirección de entrega del usuario que realiza el pago.</param>
        /// <param name="telefono">Número de teléfono de contacto del usuario que realiza el pago.</param>
        /// <param name="metodoPago">Método de pago utilizado para la transacción.</param>
        /// <param name="fechaHora">Fecha y hora en que se realiza el pago.</param>
        /// <param name="total">Monto total del pago.</param>
        public void RealizarPago(string ci, string nombreYApellido, string email, string direccion, string telefono, string metodoPago, DateTime fechaHora, decimal total)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("sp_RealizarPago", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CI", ci);
                    command.Parameters.AddWithValue("@NombreYApellido", nombreYApellido);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Direccion", direccion);
                    command.Parameters.AddWithValue("@Telf", telefono);
                    command.Parameters.AddWithValue("@Pago", metodoPago);
                    command.Parameters.AddWithValue("@FechaHora", fechaHora);
                    command.Parameters.Add("@Total", SqlDbType.Decimal).Value = total;

                    command.ExecuteNonQuery();
                }
            }
        }


        /// <summary>
        /// Elimina todos los registros del carrito de compras en la base de datos.
        /// </summary>
        public void EliminarRegistrosCarrito()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("sp_EliminarRegistrosCarrito", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
