﻿
using System;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class RecordarContrasenaD
    {

        /// <summary>
        /// Busca la contraseña asociada a un CI específico en la base de datos.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario.</param>
        /// <returns>Contraseña asociada al CI, o null si no se encuentra o el CI no es válido.</returns>
        public string BuscarContrasena(string ci)
        {
            // Variable para almacenar la contraseña encontrada en la base de datos.
            string contrasena = null;

            // Verificar si el CI no es un número o no tiene una longitud de 10 dígitos
            if (!EsNumero(ci) || ci.Length != 10)
            {
                // Si el CI no es numérico o no tiene una longitud válida, se retorna la contraseña como null.
                return contrasena;
            }

            // Cadena de conexión a la base de datos SQL Server
            string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

            // Crear la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abrir la conexión
                connection.Open();

                // Construir la consulta SQL para buscar el usuario por CI
                string query = "BuscarContrasenaPorCI";

                // Crear el comando con la consulta y la conexión

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Especificar el tipo del comando como procedimiento almacenado
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Asignar el valor del parámetro CI
                    command.Parameters.AddWithValue("@ci", ci);

                    // Agregar el parámetro de salida @contrasena
                    command.Parameters.Add(new SqlParameter("@contrasena", System.Data.SqlDbType.VarChar, 100));
                    command.Parameters["@contrasena"].Direction = System.Data.ParameterDirection.Output;

                    // Ejecutar el procedimiento almacenado
                    command.ExecuteNonQuery();

                    // Obtener el valor de salida @contrasena del procedimiento almacenado
                    contrasena = command.Parameters["@contrasena"].Value.ToString();

                }
            }

            // Retornar la contraseña encontrada (puede ser null si no se encontró ninguna contraseña).
            return contrasena;
        }


        // <summary>
        /// Verifica si una cadena de texto está compuesta únicamente por números.
        /// </summary>
        /// <param name="texto">Cadena de texto a verificar.</param>
        /// <returns>True si la cadena está compuesta solo por números, False en caso contrario.</returns>
        private bool EsNumero(string texto)
        {
            // Recorrer cada carácter en el texto.
            foreach (char c in texto)
            {
                // Verificar si el carácter actual no es un dígito numérico
                if (!char.IsDigit(c))
                {
                    // Si encontramos un carácter que no es un dígito numérico, retornamos false,
                    // indicando que la cadena no está compuesta únicamente por números.
                    return false;
                }
            }
            // Si el bucle recorre toda la cadena sin encontrar caracteres no numéricos,
            // retornamos true, indicando que la cadena está compuesta solo por números.
            return true;
        }
    }
}
