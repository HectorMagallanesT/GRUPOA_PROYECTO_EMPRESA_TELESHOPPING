﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Usuario{


    /// <summary>
    /// Obtiene o establece el número de cédula de identidad del usuario.
    /// </summary>
    public string CI { get; set; }

    /// <summary>
    /// Obtiene o establece el nombre y apellido del usuario.
    /// </summary>
    public string NombreYApellido { get; set; }

    /// <summary>
    /// Obtiene o establece el correo electrónico del usuario.
    /// </summary>
    public string Email { get; set; }

    /// <summary>
    /// Obtiene o establece la contraseña del usuario.
    /// </summary>
    public string Contrasena { get; set; }

    /// <summary>
    /// Obtiene o establece la confirmación de la contraseña del usuario.
    /// </summary>
    public string ConfirmarContrasena { get; set; }
}
