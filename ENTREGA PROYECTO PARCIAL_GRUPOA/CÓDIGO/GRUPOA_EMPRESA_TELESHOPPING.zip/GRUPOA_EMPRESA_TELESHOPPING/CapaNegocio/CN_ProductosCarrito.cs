﻿using System;

namespace CapaNegocio
{
    /// <summary>
    /// Clase que representa un producto en el carrito de compras.
    /// </summary>
    public class CN_ProductosCarrito
    {
        /// <summary>
        /// Obtiene o establece el ID del producto en el carrito.
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Obtiene o establece la imagen del producto en el carrito.
        /// </summary>
        public byte[] Foto { get; set; }

        /// <summary>
        /// Obtiene o establece el nombre del producto en el carrito.
        /// </summary>
        public string Nombre { get; set; }

        /// <summary>
        /// Obtiene o establece la descripción del producto en el carrito.
        /// </summary>
        public string Descripcion { get; set; }

        /// <summary>
        /// Obtiene o establece el precio del producto en el carrito.
        /// </summary>
        public decimal Precio { get; set; }
    }
}
